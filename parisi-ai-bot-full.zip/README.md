# parisi-ai-bot (Railway)

## Wichtigster Fehler (der bei dir sehr wahrscheinlich ist)
In deinen Screenshots sieht man **aiagenturparisi.de** (ohne Bindestrich) in Mailtrap,
aber du nutzt **ai-agenturparisi.de** (mit Bindestrich) bei IONOS (kontakt@ai-agenturparisi.de).

➡️ Das muss 1:1 exakt gleich sein. Sonst bleibt in Mailtrap alles auf **Missing**.

## Was du in Mailtrap brauchst
- Sending Domain: **ai-agenturparisi.de** (genau so wie bei IONOS)
- SMTP:
  - Host: `live.smtp.mailtrap.io`
  - Port: `587`
  - Username: `api`
  - Password: dein **Mailtrap SMTP API Token**

## FROM_MAIL – was ist richtig?
Du kannst beides machen:

### Option A (empfohlen): kontakt@...
- `FROM_MAIL=kontakt@ai-agenturparisi.de`
- Vorteil: wirkt seriös, Replies kommen direkt an.

### Option B: no-reply + Reply-To
- `FROM_MAIL=no-reply@ai-agenturparisi.de`
- `REPLY_TO=kontakt@ai-agenturparisi.de`
- Vorteil: Inbox sauber, aber Kunden können trotzdem antworten.

Wichtig: Die Domain muss in Mailtrap verifiziert sein (DNS Records gesetzt), sonst landet es eher im Spam / wird abgelehnt.

## Railway Setup (kurz)
1) In Railway: Service öffnen → Variables
2) Diese Variablen setzen:
   - FROM_MAIL
   - (optional) REPLY_TO
   - SMTP_HOST
   - SMTP_PORT
   - SMTP_USER
   - SMTP_PASS
   - (optional) TO_MAIL (wo die Leads ankommen sollen)
3) Deploy

## Test
Nach Deploy:
- `POST https://<deine-railway-url>/api/test-email`
  Body: `{ "to": "deine@email.de" }`
