// Kept for backward compatibility if old code imports ./mailer
module.exports = require("./email_notifications");
